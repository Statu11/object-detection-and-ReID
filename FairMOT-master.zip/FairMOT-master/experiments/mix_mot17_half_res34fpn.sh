cd src
python train.py mot --exp_id mix_mot17_half_res34fpn --arch 'resfpndcn_34' --data_cfg '../src/lib/cfg/data_half.json'
cd ..